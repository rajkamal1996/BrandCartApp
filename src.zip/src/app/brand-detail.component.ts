import { Component, OnInit } from '@angular/core';
import {TranslateService} from 'ng2-translate';
import {ActivatedRoute} from '@angular/router';
declare var google: any;
@Component({
  templateUrl: './map-display/map-display.component.html'
})
export class BrandDetailComponent implements OnInit {
  public brandName;
    constructor(private translate:TranslateService,private route : ActivatedRoute) { 
    translate.addLangs(["en", "fr"]);
    translate.setDefaultLang('en');

    let browserLang = translate.getBrowserLang();
    translate.use(browserLang.match(/en|fr/) ? browserLang : 'en');
  }

  ngOnInit() {
    
      let name = this.route.snapshot.params['name'];
      this.brandName = name;  
    this.initMap();
    }
    public initMap():void {
      var myLatLng = {lat: -25.363, lng: 131.044};
      var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 17,
        center: myLatLng
      });

      var marker = new google.maps.Marker({
        position: myLatLng,
        map: map,
        title: 'Hello World!'
      });
  }
}