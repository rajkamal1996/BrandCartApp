import { Component, Input, OnInit, OnChanges } from '@angular/core';
import {TranslateService} from 'ng2-translate'; 
import {Router} from "@angular/router";
import { SharedService } from '../shared.service';
import {DomSanitizer, SafeResourceUrl} from "@angular/platform-browser";
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css'],
  providers: [SharedService]
})
export class SearchComponent implements OnInit {
  message : string;
  protected captain: string;
  imageLink: SafeResourceUrl;
  public searchData = [
    { name: 'ACER'},
    { name: 'APPLE'},
    { name: 'ADIDAS'},
    { name: 'NIKE'},
    { name: 'BLACK FOREST' },
    { name: 'REEBOK' },
    { name: 'DOMINOS' }
  ];

  constructor(private translate:TranslateService,private sanitizer : DomSanitizer, private router: Router, private data :SharedService ) { 

    translate.addLangs(["en", "fr"]);
    translate.setDefaultLang('en');

    let browserLang = translate.getBrowserLang();
    translate.use(browserLang.match(/en|fr/) ? browserLang : 'en');
  
  
  }

  searchBrand(){ 
    this.data.ChangeMessage("Acer");
this.router.navigate(['\map-display']);

}
  
onSelect(brand){
  this.router.navigate(['/search' , brand.name]);
  
}

  ngOnInit() {
  this.data.currentmessage.subscribe(message => this.message= message);
  }

}
