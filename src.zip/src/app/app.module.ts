import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import {TranslateModule} from 'ng2-translate';
import {RouterModule } from '@angular/router';
import { SharedService } from './shared.service';
import {AppRouteModule} from './app-routeModule';
import{routingComponents} from './app-routeModule';
import { AppComponent } from './app.component';


@NgModule({
  declarations: [
    AppComponent,
    routingComponents      
  
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    TranslateModule.forRoot(),
    AppRouteModule
  ],
  exports: [
    TranslateModule
   ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
